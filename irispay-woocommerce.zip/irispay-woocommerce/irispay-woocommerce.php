<?php
/**
 * Plugin Name: IRIS Pay for WooCommerce
 * Plugin URI: https://irispay.bg
 * Description: IRIS Pay payment gateway for WooCommerce.
 * Version: 1.0.0
 * Author: IRIS Pay
 * Author URI: https://irispay.bg
 * Text Domain: irispay-woocommerce
 * Domain Path: /languages
 *
 * @package IRISPay_WooCommerce
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Initialize IRIS Pay Gateway
 */
function irispay_woocommerce_init()
{
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    require_once plugin_dir_path(__FILE__) . 'includes/class-wc-gateway-irispay.php';

    add_filter('woocommerce_payment_gateways', 'irispay_add_gateway');
}
add_action('plugins_loaded', 'irispay_woocommerce_init');

/**
 * Add the gateway to WooCommerce
 *
 * @param array $gateways Current gateways.
 * @return array Updated gateways.
 */
function irispay_add_gateway($gateways)
{
    $gateways[] = 'WC_Gateway_IrisPay';
    return $gateways;
}

/**
 * Add settings link to plugins page
 *
 * @param array $links Plugin links.
 * @return array Updated links.
 */
function irispay_woocommerce_settings_link($links)
{
    $settings_link = '<a href="admin.php?page=wc-settings&tab=checkout&section=irispay">' . __('Settings', 'irispay-woocommerce') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'irispay_woocommerce_settings_link');
