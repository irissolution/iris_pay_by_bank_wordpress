<?php
/**
 * IRIS Pay Payment Gateway
 *
 * @package IRISPay_WooCommerce
 */

if (!defined('ABSPATH')) {
	exit;
}

/**
 * WC_Gateway_IrisPay class
 */
class WC_Gateway_IrisPay extends WC_Payment_Gateway
{
	public $api_key;
	public $environment;
	public $sdk_version;


	/**
	 * Constructor
	 */
	public function __construct()
	{
		$this->id = 'irispay';
		$this->icon = 'https://irispay.bg/resource/public/image/iris-logo.svg';
		$this->has_fields = false;
		$this->method_title = __('IRIS Pay', 'irispay-woocommerce');
		$this->method_description = __('Accept payments via IRIS Pay.', 'irispay-woocommerce');

		// Load settings
		$this->init_form_fields();
		$this->init_settings();

		// Define user settings
		$this->title = $this->get_option('title');
		$this->description = $this->get_option('description');
		$this->enabled = $this->get_option('enabled');

		$this->api_key = $this->get_option('api_key');

		$this->environment = $this->get_option('environment', 'sandbox');
		$this->sdk_version = $this->get_option('sdk_version', 'prod');

		// Actions
		add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
		add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));

		// Webhook and Polling endpoints
		add_action('woocommerce_api_irispay_webhook', array($this, 'handle_webhook'));
		add_action('woocommerce_api_irispay_status', array($this, 'handle_status_check'));
	}

	/**
	 * Initialize Gateway Settings Form Fields
	 */
	public function init_form_fields()
	{
		$this->form_fields = array(
			'enabled' => array(
				'title' => __('Enable/Disable', 'irispay-woocommerce'),
				'type' => 'checkbox',
				'label' => __('Enable IRIS Pay', 'irispay-woocommerce'),
				'default' => 'yes',
			),
			'title' => array(
				'title' => __('Title', 'irispay-woocommerce'),
				'type' => 'text',
				'description' => __('This controls the title which the user sees during checkout.', 'irispay-woocommerce'),
				'default' => __('IRIS Pay', 'irispay-woocommerce'),
				'desc_tip' => true,
			),
			'description' => array(
				'title' => __('Description', 'irispay-woocommerce'),
				'type' => 'textarea',
				'description' => __('This controls the description which the user sees during checkout.', 'irispay-woocommerce'),
				'default' => __('Pay securely via your bank with IRIS Pay.', 'irispay-woocommerce'),
			),
			'api_key' => array(
				'title' => __('API Key', 'irispay-woocommerce'),
				'type' => 'text',
				'description' => __('Enter your IRIS Pay API Key.', 'irispay-woocommerce'),
				'default' => '',
			),
			'environment' => array(
				'title' => __('Environment', 'irispay-woocommerce'),
				'type' => 'select',
				'default' => 'sandbox',
				'options' => array(
					'sandbox' => __('Sandbox', 'irispay-woocommerce'),
					'live' => __('Production (Live)', 'irispay-woocommerce'),
				),
				'description' => __('Select IRIS Pay backend environment.', 'irispay-woocommerce'),
			),
			'sdk_version' => array(
				'title' => __('SDK Version', 'irispay-woocommerce'),
				'type' => 'select',
				'default' => 'prod',
				'options' => array(
					'prod' => __('Production SDK', 'irispay-woocommerce'),
					'dev' => __('Development SDK', 'irispay-woocommerce'),
				),
				'description' => __('Select which UI SDK to load.', 'irispay-woocommerce'),
			),
		);
	}

	/**
	 * Check if this gateway is enabled and available in the user's country
	 */
	public function is_available()
	{
		$is_enabled = $this->enabled === 'yes';

		// Optional: you can add more checks here (e.g., specific currencies)
		// but returning $is_enabled forces WooCommerce to listen to our setting.
		return $is_enabled;
	}

	/**
	 * Process the payment and return the result
	 */
	public function process_payment($order_id)
	{
		$order = wc_get_order($order_id);
		return array(
			'result' => 'success',
			'redirect' => $order->get_checkout_payment_url(true),
		);
	}

	/**
	 * Output the IRIS payment form on the receipt page
	 */
	public function receipt_page($order_id)
	{
		echo '<p>' . esc_html__('Please wait while we initialize the secure payment gateway...', 'irispay-woocommerce') . '</p>';
		$this->generate_iris_form($order_id);
	}

	// API Helpers
	private function getBackendUrl()
	{
		return $this->environment === 'live' ? 'https://developer.irispay.bg/' : 'https://developer.sandbox.irispay.bg/';
	}

	private function getPayByClickBackendUrl()
	{
		return $this->environment === 'live' ? 'https://paybyclick.irispay.bg/backend/' : 'https://dev.paybyclick.irispay.bg/backend/';
	}

	private function getSdkUrls()
	{
		if ($this->sdk_version === 'dev') {
			return [
				'js' => 'https://websdk.infn.dev/assets/irispay-ui/elements.js',
				'css' => 'https://websdk.infn.dev/assets/irispay-ui/styles.css'
			];
		}

		return [
			'js' => 'https://websdk.irispay.bg/assets/irispay-ui/elements.js',
			'css' => 'https://websdk.irispay.bg/assets/irispay-ui/styles.css'
		];
	}

	private function getUserHash($publicHash)
	{
		$url = rtrim($this->getBackendUrl(), '/') . '/api/8/signup/public';
		$payload = ['publicHash' => $publicHash];

		$response = wp_remote_post($url, array(
			'headers' => array('accept' => 'application/json', 'Content-Type' => 'application/json'),
			'body' => wp_json_encode($payload),
			'timeout' => 10,
		));

		if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
			return false;
		}

		$body = json_decode(wp_remote_retrieve_body($response), true);
		return $body['userHash'] ?? false;
	}

	private function getHookHash($currency, $description, $orderId, $sum, $webhookUrl)
	{
		$url = rtrim($this->getPayByClickBackendUrl(), '/') . '/payment/plugin/create';
		$payload = [
			'currency' => $currency,
			'description' => (string) $description,
			'key' => $this->api_key,
			'orderId' => (string) $orderId,
			'sum' => (float) $sum,
			'hookUrl' => $webhookUrl,
		];

		$this->log("[API Request] Creating plugin payment hook: URL: " . $url . " | Payload: " . json_encode($payload));

		$response = wp_remote_post($url, array(
			'headers' => array(
				'accept' => 'application/json',
				'Content-Type' => 'application/json',
			),
			'body' => wp_json_encode($payload),
			'timeout' => 10,
		));

		if (is_wp_error($response)) {
			$this->log("[API Error] wp_remote_post failed: " . $response->get_error_message());
			return false;
		}

		$code = wp_remote_retrieve_response_code($response);
		$body_str = wp_remote_retrieve_body($response);
		$this->log("[API Response] Code: " . $code . " | Body: " . $body_str);

		if ($code !== 200) {
			return false;
		}

		return json_decode($body_str, true);
	}

	private function getPaymentStatus($hookHash)
	{
		$url = rtrim($this->getBackendUrl(), '/') . '/api/8/status/' . urlencode($hookHash);
		$this->log("[API Request] Checking status: URL: " . $url);

		$response = wp_remote_get($url, array(
			'headers' => array(
				'accept' => 'application/json',
			),
			'timeout' => 10,
		));

		if (is_wp_error($response)) {
			$this->log("[API Error] wp_remote_get status check failed: " . $response->get_error_message());
			return false;
		}

		$code = wp_remote_retrieve_response_code($response);
		$body_str = wp_remote_retrieve_body($response);
		$this->log("[API Response] Status Code: " . $code . " | Body: " . $body_str);

		if ($code !== 200) {
			return false;
		}

		return json_decode($body_str, true);
	}

	/**
	 * Generate IRIS SDK Form
	 */
	private function generate_iris_form($order_id)
	{
		$order = wc_get_order($order_id);

		$state = 'wc_order_' . $order_id . '_' . time();
		$webhook_url = add_query_arg('state', $state, WC()->api_request_url('irispay_webhook'));

		// Dynamically adjust localhost/127.0.0.1 to ngrok if accessed via ngrok
		if (isset($_SERVER['HTTP_HOST']) && !empty($_SERVER['HTTP_HOST'])) {
			$site_url = get_option('siteurl');
			$site_host = wp_parse_url($site_url, PHP_URL_HOST);
			$current_host = $_SERVER['HTTP_HOST'];

			if ($site_host !== $current_host && (strpos($current_host, 'ngrok') !== false || $site_host === 'localhost' || $site_host === '127.0.0.1')) {
				$webhook_url = str_replace($site_host, $current_host, $webhook_url);
				if (strpos($current_host, 'ngrok') !== false) {
					$webhook_url = str_replace('http://', 'https://', $webhook_url);
				}
			}
		}

		$this->log("[Webhook URL Generated] Order #" . $order_id . " | Webhook URL: " . $webhook_url);

		$success_url = $this->get_return_url($order);
		$error_url = wc_get_checkout_url();

		$hook_data = $this->getHookHash(
			$order->get_currency(),
			'Order #' . $order->get_order_number(),
			$order_id,
			(float) $order->get_total(),
			$webhook_url
		);

		if (!$hook_data || !isset($hook_data['hookHash'])) {
			$this->log("[Error] Hook data initialization failed for Order #" . $order_id);
			echo '<div class="woocommerce-error">' . esc_html__('Error initializing payment (HookHash). Please check your API Key.', 'irispay-woocommerce') . '</div>';
			return;
		}

		$hook_hash = $hook_data['hookHash'];
		$public_hash = $hook_data['publicHash'];
		$to_iban = $hook_data['iban'];
		$merchant_name = $hook_data['merchantName'];

		$user_hash = $this->getUserHash($public_hash);
		if (!$user_hash) {
			$this->log("[Error] User hash initialization failed for Order #" . $order_id . " | Public Hash: " . $public_hash);
			echo '<div class="woocommerce-error">' . esc_html__('Error initializing payment (UserHash).', 'irispay-woocommerce') . '</div>';
			return;
		}

		// Save hook hash to order
		$order->update_meta_data('_irispay_hook_hash', $hook_hash);
		$order->save();

		$payment_data = [
			'currency' => $order->get_currency(),
			'description' => 'Order #' . $order->get_order_number(),
			'sum' => (float) $order->get_total(),
			'toIban' => $to_iban,
			'publicHash' => $public_hash,
			'merchant' => $merchant_name
		];

		$payment_data_b64 = base64_encode(json_encode($payment_data));
		$sdk_urls = $this->getSdkUrls();
		?>

		<link rel="stylesheet" href="<?php echo esc_url($sdk_urls['css']); ?>" type="text/css" />
		<script src="<?php echo esc_url($sdk_urls['js']); ?>" type="text/javascript"></script>

		<style>
			#irispay-payment-section {
				background: #fff;
				padding: 25px;
				border: 1px solid #ddd;
				border-radius: 8px;
				margin-bottom: 30px;
			}

			#irispay-container {
				min-height: 150px;
			}
		</style>

		<div id="irispay-payment-section">
			<div id="irispay-container"></div>
		</div>

		<script type="text/javascript">
			document.addEventListener('DOMContentLoaded', function () {
				var container = document.getElementById("irispay-container");
				var paymentElement = document.createElement("irispay-component");
				paymentElement.setAttribute("type", "payment-data");
				paymentElement.setAttribute("show_bank_selector", "true");
				var paymentDataStr = atob("<?php echo esc_js($payment_data_b64); ?>");
				paymentElement.setAttribute("payment_data", paymentDataStr);
				paymentElement.setAttribute("hookhash", "<?php echo esc_js($hook_hash); ?>");
				paymentElement.setAttribute("userhash", "<?php echo esc_js($user_hash); ?>");
				paymentElement.setAttribute("backend", "<?php echo esc_js($this->getBackendUrl()); ?>");

				container.appendChild(paymentElement);

				var successEvents = ['lastStep', 'laststep', 'paymentSuccess', 'payment-success', 'done', 'finished', 'success'];
				successEvents.forEach(function (evtName) {
					paymentElement.addEventListener(evtName, function (e) {
						console.log('[IRIS Pay] SDK Event detected:', evtName);
						startPolling();
					});
				});

				// Ultimate fallback: Monitor internal state changes if possible
				var originalDispatch = paymentElement.dispatchEvent;
				paymentElement.dispatchEvent = function(event) {
					console.log('[IRIS Pay] Raw Event:', event.type);
					if (event.type.toLowerCase().includes('success') || event.type.toLowerCase().includes('laststep') || event.type.toLowerCase() === 'done') {
						startPolling();
					}
					return originalDispatch.apply(this, arguments);
				};

				function startPolling() {
					container.innerHTML = '<div style="text-align:center; padding:20px;">Завършване на плащането...</div>';
					var pollUrl = '<?php echo esc_url_raw(add_query_arg("order_id", $order_id, WC()->api_request_url("irispay_status"))); ?>';

					var timer = setInterval(function () {
						fetch(pollUrl)
							.then(res => res.text())
							.then(text => {
								try {
									var jsonStart = text.indexOf('{');
									if (jsonStart !== -1) {
										var data = JSON.parse(text.substring(jsonStart).trim());
										if (data.status === 'success') {
											clearInterval(timer);
											window.location.href = data.redirect || '<?php echo esc_js($success_url); ?>';
										} else if (data.status === 'error') {
											clearInterval(timer);
											window.location.href = '<?php echo esc_js($error_url); ?>';
										}
									}
								} catch(err) {
									console.error('[IRIS Pay] Safe Parse Error:', err, text);
								}
							})
							.catch(err => console.error('[IRIS Pay] Fetch error:', err));
					}, 3000);
				}
			});
		</script>
		<?php
	}

	/**
	 * Handle Webhook
	 */
	public function handle_webhook()
	{
		$this->log("[Webhook Received] Request URI: " . $_SERVER['REQUEST_URI'] . " | GET: " . json_encode($_GET) . " | POST: " . file_get_contents('php://input'));

		if (!isset($_GET['state'])) {
			$this->log("[Webhook Error] No state provided.");
			echo "FAIL";
			exit;
		}

		$state_parts = explode('_', $_GET['state']);
		if (count($state_parts) < 3 || $state_parts[0] !== 'wc' || $state_parts[1] !== 'order') {
			$this->log("[Webhook Error] Invalid state format: " . $_GET['state']);
			echo "FAIL";
			exit;
		}

		$order_id = (int) $state_parts[2];
		$order = wc_get_order($order_id);
		if (!$order) {
			$this->log("[Webhook Error] Order not found: " . $order_id);
			echo "FAIL";
			exit;
		}

		$hook_hash = $order->get_meta('_irispay_hook_hash');
		if (!$hook_hash) {
			$this->log("[Webhook Error] Hook hash not found for Order #" . $order_id);
			echo "FAIL";
			exit;
		}

		// Read status from GET parameter sent directly by IRIS Pay
		$final_status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
		$this->log("[Webhook] Order #" . $order_id . " | Hook Hash: " . $hook_hash . " | Status: " . $final_status);

		if ($final_status === 'CONFIRMED') {
			if (!$order->is_paid()) {
				$order->payment_complete($hook_hash);
				$order->add_order_note(sprintf(__('IRIS Pay Payment Confirmed via Webhook (Hook: %s)', 'irispay-woocommerce'), $hook_hash));
				$this->log("[Webhook Success] Order #" . $order_id . " marked as paid.");
			} else {
				$this->log("[Webhook] Order #" . $order_id . " was already paid.");
			}
			echo "OK";
			exit;
		} elseif (in_array($final_status, ['REJECTED', 'FAILED', 'CANCELLED', 'EXPIRED'])) {
			$order->update_status('failed', sprintf(__('IRIS Pay Webhook failure: %s', 'irispay-woocommerce'), $final_status));
			$this->log("[Webhook Failure] Order #" . $order_id . " status set to failed due to " . $final_status);
			echo "OK"; // Acknowledge receipt
			exit;
		}

		$this->log("[Webhook Pending/Unknown] Status: " . $final_status);
		echo "FAIL";
		exit;
	}

	/**
	 * Handle Status Check (Polling)
	 */
	public function handle_status_check()
	{
		$order_id = isset($_GET['order_id']) ? (int) $_GET['order_id'] : 0;
		$order = wc_get_order($order_id);

		if (!$order) {
			$this->log("[Polling Error] Invalid order ID: " . $order_id);
			wp_send_json(array('status' => 'error', 'error' => 'Invalid order.'));
		}

		$this->log("[Polling Check] Order #" . $order_id . " | Current Paid Status: " . ($order->is_paid() ? 'PAID' : 'UNPAID') . " | Status: " . $order->get_status());

		if ($order->is_paid()) {
			$this->log("[Polling Success] Order #" . $order_id . " is paid. Redirecting user to: " . $this->get_return_url($order));
			wp_send_json(array('status' => 'success', 'redirect' => $this->get_return_url($order)));
		}

		// Since we don't have an agent hash/credentials, querying getPaymentStatus() directly will fail.
		// Instead, we purely rely on the webhook updating the order status in the database.
		// If the webhook is not processed yet, keep polling.
		wp_send_json(array('status' => 'pending'));
	}

	/**
	 * Log diagnostic messages to wp-content/irispay.log
	 */
	private function log($message)
	{
		$log_file = WP_CONTENT_DIR . '/irispay.log';
		$timestamp = date('Y-m-d H:i:s');
		$formatted = "[{$timestamp}] {$message}" . PHP_EOL;
		file_put_contents($log_file, $formatted, FILE_APPEND);
	}
}

