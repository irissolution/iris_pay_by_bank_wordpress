<?php

/*
	Plugin Name: IRIS Solutions - Pay by Bank
	Plugin URI: https://www.irisbgsf.com
	Description: ”Pay by Bank” for WooCommerce gives your store the flexibility to make “account-to-account” payments. Activating the extension gives customers a choice of more than 40 banks and payment institutions.
	Version: 1.0.0
	Author: IRIS Solutions
	Author URI: https://www.irisbgsf.com
    Copyright 2023 IRIS Solutions (email : support@irisbgsf.com)
	Text Domain: irispay
	Domain Path: /lang/    
*/

register_activation_hook(__FILE__, 'irispay_activation');
register_deactivation_hook(__FILE__, 'irispay_deactivation');
function irispay_activation() {
    if (!wp_next_scheduled('irispay_cron_event')) {
        wp_schedule_event(time(), 'hourly', 'irispay_cron_event');
    }
}
function irispay_deactivation() {
    wp_clear_scheduled_hook('irispay_cron_event');
}

add_filter('woocommerce_payment_gateways', 'add_iris_payment');
add_action('plugins_loaded', 'init_iris_payment');
add_action('irispay_cron_event', 'irispay_cron_job');

//add_action('init', 'irispay_cron_job'); // test the cron


function add_iris_payment($methods) {
    $methods[] = 'Iris_Payment_Gateway'; 
    return $methods;
}
function irispay_cron_job() {
    $irispay = new Iris_Payment_Gateway();
    $irispay->CancelPendingOrders();
}


function init_iris_payment() {
    
    class Iris_Payment_Gateway extends WC_Payment_Gateway {

		public function __construct() {
			if (file_exists(dirname(__FILE__).'/lang/irispay-'.get_locale().'.mo')) load_textdomain('irispay', dirname(__FILE__).'/lang/irispay-'.get_locale().'.mo');
			else load_textdomain('irispay', dirname(__FILE__).'/lang/en_US.mo');
			$this->id = 'irispay';
			$this->icon = '';
			$this->has_fields = True;
			$this->method_title = __('IRIS Solutions - Pay by Bank', 'irispay');
			$this->method_description = __('“Pay by Bank” for WooCommerce gives your store the flexibility to make “account-to-account” payments. Activating the extension gives customers a choice of more than 40 banks and payment institutions.', 'irispay');;
			$this->supports = array('products');			
			$this->init_form_fields();
			
			$this->init_settings();
			$this->title = $this->get_option('title');
			$this->description = $this->get_option('description');
			$this->enabled = $this->get_option('enabled');

			$this->testmode = $this->get_option('testmode');
			$this->merchant_key = $this->get_option('merchant_key');
			$this->merchant_iban = $this->get_option('merchant_iban');
			$this->payment_name = $this->get_option('payment_name');
			$this->payment_descr = $this->get_option('payment_descr');
			$this->cronperiod = $this->get_option('cronperiod');
			
			add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
			add_action('woocommerce_api_irispay', array($this, 'webhook'));
			add_filter('plugin_action_links_irispay/irispay.php', array($this, 'SettingsLink'));

		}

		function SettingsLink( $links ) {
			$url = esc_url(get_admin_url() . 'admin.php?page=wc-settings&tab=checkout&section=irispay');
			$settings_link = "<a href='$url'>" . __('Settings') . '</a>';
			array_push($links, $settings_link);
			return $links;
		}

		function admin_options() {
			$url = plugins_url('', __FILE__);
			$curlang = get_bloginfo('language');
			if ($curlang == 'bg-BG') $termslink = 'https://www.irisbgsf.com/_files/ugd/300e16_aa3fbae7df45433c9969b81baada4a80.pdf';
			else $termslink = 'https://en.irisbgsf.com/_files/ugd/0ec3b2_1637f76472054a55b8949a24c82c3577.pdf';
			if ($this->testmode === 'yes') $reglink = 'https://openid.finoid.eu/auth/realms/payperclick/login-actions/registration?client_id=payperclick&tab_id=sOt-Dxw9hCs';
			else $reglink = 'https://id.dev.paybyclick.irispay.bg/realms/payperclick/login-actions/registration?client_id=payperclick&tab_id=ggYCBUdS8Kw';
			if ($curlang == 'bg-BG') $howtolink = 'https://www.irisbgsf.com/paywithbank';
			else $howtolink = 'https://en.irisbgsf.com/paywithbank';
			echo "
				<div style='background: #fff; padding: 10px;'>
					<a href='https://www.irisbgsf.com' target='_blank'><img src='$url/irispay.jpg' style='max-width: 100px; vertical-align: middle; margin-right: 30px;' /></a><a href='$reglink' target='_blank' style='font-size: 18px; text-decoration: none; color: #273574; margin-right: 20px;'>".__('Merchant Registration', 'irispay')."</a><a href='$termslink' target='_blank' style='font-size: 18px; text-decoration: none; color: #273574; margin-right: 20px;'>".__('Terms & Conditions', 'irispay')."</a><a href='$howtolink' target='_blank' style='font-size: 18px; text-decoration: none; color: #273574; margin-right: 20px;'>".__('How To Use', 'irispay')."</a>
				</div>
				<h2>".__('IRIS Pay By Bank Settings', 'irispay')."</h2>
		 		<table class='irispaysettings form-table'>
		 	";
		 	echo $this->generate_settings_html();
		 	echo "
		 		</table>
		 	";
		}

		public function CancelPendingOrders() {
			$cronperiod = $this->cronperiod?$this->cronperiod:72;
			$args = array(
		        'status'        => 'wc-on-hold',
		        'date_created'  => '<' . (time() - 3600*$cronperiod),
		        'limit'         => -1,
		    );
    		$orders = wc_get_orders($args);
    		foreach ($orders as $order) {
			    if ($order->get_payment_method() == 'irispay') {
					$order->update_status('wc-cancelled');
			    }
			}
		}


		public function init_form_fields() {
			$msg = __('Woocommerce default setting', 'irispay');
			if (!in_array(get_woocommerce_currency(), ['BGN', 'RON', 'EUR'])) $msg .= ". <span style='color: red;'>".__(sprintf("%s currency is not supported by Iris Pay (supported are: BGN, RON, EUR)", get_woocommerce_currency()), 'irispay')."</span>";
			$this->form_fields = array(
			    'enabled' => array(
			        'title' => __('Enable/Disable', 'irispay'),
			        'type' => 'checkbox',
			        'label' => __('Enable IRIS Solutions Payment', 'irispay'),
			        'default' => 'yes'
			    ),
			    'testmode' => array(
			        'title' => __('Test Mode', 'irispay'),
			        'type' => 'checkbox',
			        'label' => __('Try the payment in test mode', 'irispay'),
			        'default' => 'no'
			    ),
			    'title' => array(
			        'title' => __('Title', 'irispay'),
			        'type' => 'text',
			        'default' => __('IRIS Pay by Bank', 'irispay'),
			        'desc_tip'      => true,
			    ),
				'description' => array(
					'title'       => __('Description', 'irispay' ),
					'type'        => 'text',
					'description' => __('This controls the description which the user sees during checkout.', 'irispay'),
					'default'     => __('IRIS Pay By Bank Gateway', 'irispay'),
					'desc_tip'      => true,
				),
				'merchant_key' => array(
					'title'       => __('IRIS Pay By Bank - Merchant Key', 'irispay'),
			        'description' => __('Your Merchant Key, obtained from your IRIS Solutions, Merchant portal account.', 'irispay' ),
			        'default'     => 'f75fa38d-ca1b-4241-a01a-58965d444aba',
					'type'        => 'text',
					'desc_tip'      => true,
				),
				'merchant_iban' => array(
					'title'       => __('IRIS Pay By Bank - Merchant Account (IBAN)', 'irispay'),
					'description' => __('Your Merchant Account, obtained from your IRIS Solutions, Merchant portal account.', 'irispay' ),
					'default'     => 'BG85IORT80947826532954',
					'type'        => 'text',
					'desc_tip'      => true,
				),
				'payment_name' => array(
					'title'       => __('Short Description of the payment', 'irispay'),
					'type'        => 'text',
					'description' => __('Will be present in the fund transfer form of the bank in the description placeholder, up to 34 symbols.', 'irispay'),
					'maxlength' => 34,
					'desc_tip'      => true,
				),
				'payment_descr' => array(
					'title'       => __('Full Description of the payment', 'irispay'),
					'type'        => 'text',
					'description' => __('Will be present only in the IRIS Solutions systems, up to 240 symbols.', 'irispay'),
					'maxlength' => 240,
					'default'     => __('Payment at ', 'irispay').get_bloginfo('name'),
					'desc_tip'      => true,
				),
				'currency' => array(
					'title'       => __('Currency', 'irispay').': '.get_woocommerce_currency(),
					'type'        => 'hidden',
					'description' => $msg,
				),
				'cronperiod' => array(
					'title'       => __('Cancel pending orders after (hours)', 'irispay'),
					'type'        => 'text',
					'css'		=> 'max-width: 60px;',
					'default'     => 72
				),
				 
			);		
		}

		public function payment_fields() {
		    if (!$this->merchant_iban || !$this->merchant_key) {
        		echo '<p style="color: red;">'.__('IrisPay is not configured properly!<br />Please contact the site owner.', 'irispay').'</p>';
		    }
		    else echo $this->description;
    	}

		public function process_payment($order_id) {
		    global $woocommerce;
		    $order = new WC_Order($order_id);
		    $args = [
		    	'currency'=>$order->get_currency(),
		    	'hookUrl'=>get_site_url().'/wc-api/irispay/?id='.$order->get_id(),
		    	'name'=>$this->payment_name,
		    	'description'=>$this->payment_descr,
		    	'redirectUrl'=>$this->get_return_url($order),
		    	'orderId'=>$order->get_id(),
		    	'sum'=>$order->get_total(),
		    	'toIban'=>$this->merchant_iban,
		    	'lang'=>'bg'
		    ];
		    if ($this->testmode === 'yes') $url = 'https://payperclick.infn.dev/backend/payment/external/';
			else $url = 'https://paybyclick.irispay.bg/backend/payment/external/';
		    $resp = $this->HTTPPostJSON($url.$this->merchant_key, $args);
		    $resp = json_decode($resp);
		    if (isset($resp->paymentLink)) {
		    	update_post_meta($order_id, 'payentlink', $resp->paymentLink);
			    $order->update_status('on-hold', __('Awaiting Iris payment', 'irispay'));
			    $woocommerce->cart->empty_cart();
			    return array(
			        'result' => 'success',
			        'redirect' => $resp->paymentLink
			    );
			}
		}

		public function webhook() {
			$fh = fopen('ipnlog.txt', 'ab');
			fwrite($fh, 'GET: '.json_encode($_GET).'<br />POST: '.json_encode($_POST));
			fclose($fh);
			if ($_GET['status'] == 'CONFIRMED') {
				$order = wc_get_order($_GET['id']);
				$order->payment_complete();
				$order->reduce_order_stock();
			}
		}

		function HTTPPostJSON($url, $postdata=0) {
		    $ch = curl_init();
		    curl_setopt($ch, CURLOPT_URL, $url);
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
		    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
		    curl_setopt($ch, CURLOPT_POST, true);
		    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		    if (is_array($postdata)) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postdata));
		    $result = curl_exec($ch);
		    curl_close($ch);
		    return $result;
		}


	}
}

?>